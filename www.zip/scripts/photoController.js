// angular.module('starter.controllers', [])
//   .controller('PhotoCtrl', function($scope) {

  

// })